
public class Main {
  public static void main(String[] args) {
    int nota1 = 6;
    int nota2 = 8;

    int media = (nota1 + nota2) / 2;
    System.out.println("a media das notas é: " + media);
  }

}