
public class Main {
  public static void main(String[] args) {
    String name1 = "isabely";
    String name2 = "nicoly";
    System.out.println("unindo os dois nomes: " + name1 + name2);
  }

}